{
  "mod_id": "lovely_lilies",
  "minecraft": "1.20.1",
  "forge": "47.2.20",
  "java": "17",
  "gradle": "8.1.1",
  "visual_overhang": "Models intentionally use coordinates below 0 and above 16, including -4/-2/18/20; giant forms reach 56-68 Y.",
  "collision": "Java collision remains compact (2..14 in X/Z); giant forms remain one-block physical footprints.",
  "render_layer": "All registered plant blocks are set to cutout() during FMLClientSetupEvent.",
  "species": {
    "true_lilies": [
      "Königslilie",
      "Tigerlilie",
      "Türkenbundlilie"
    ],
    "oriental_bed_lilies": [
      "Rot",
      "Pink",
      "Weiß",
      "Gelb"
    ],
    "mutated_tiger_lily": [
      "one-block",
      "tropical multi-stem visual",
      "giant form"
    ],
    "bride_lily": [
      "one-block",
      "two-block",
      "potted white-grey patterned narrow-neck vase",
      "giant form"
    ],
    "lily_named_non_lilium": [
      "Schwertlilie (Iris)",
      "Seerosenlilie/Wasserlilie",
      "Taglilie",
      "Wüstenlilie"
    ],
    "multi_stem": [
      "Schwertlilie",
      "Seerosenlilie",
      "Taglilie",
      "Wüstenlilie"
    ]
  },
  "note": "Giant variants are single registered blocks with multi-block-tall visual models; their physical collision stays small and therefore avoids fragile runtime multiblock placement/state logic."
}