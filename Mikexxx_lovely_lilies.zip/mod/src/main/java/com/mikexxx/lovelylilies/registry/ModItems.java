package com.mikexxx.lovelylilies.registry;

import com.mikexxx.lovelylilies.LovelyLilies;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LovelyLilies.MOD_ID);

    private ModItems() {}

    private static RegistryObject<Item> blockItem(String name, Supplier<? extends Block> block) {
        return ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    public static final RegistryObject<Item> KOENIGSLILIE = blockItem("koenigslilie", ModBlocks.KOENIGSLILIE);
    public static final RegistryObject<Item> TIGERLILIE = blockItem("tigerlilie", ModBlocks.TIGERLILIE);
    public static final RegistryObject<Item> TUERKENBUNDLILIE = blockItem("tuerkenbundlilie", ModBlocks.TUERKENBUNDLILIE);
    public static final RegistryObject<Item> ORIENTAL_ROT = blockItem("oriental_beetlilie_rot", ModBlocks.ORIENTAL_ROT);
    public static final RegistryObject<Item> ORIENTAL_PINK = blockItem("oriental_beetlilie_pink", ModBlocks.ORIENTAL_PINK);
    public static final RegistryObject<Item> ORIENTAL_WEISS = blockItem("oriental_beetlilie_weiss", ModBlocks.ORIENTAL_WEISS);
    public static final RegistryObject<Item> ORIENTAL_GELB = blockItem("oriental_beetlilie_gelb", ModBlocks.ORIENTAL_GELB);
    public static final RegistryObject<Item> MUTIERTE_TIGERLILIE = blockItem("mutierte_tigerlilie", ModBlocks.MUTIERTE_TIGERLILIE);
    public static final RegistryObject<Item> BRAUTLILIE = blockItem("brautlilie", ModBlocks.BRAUTLILIE);
    public static final RegistryObject<Item> BRAUTLILIE_2 = blockItem("brautlilie_2", ModBlocks.BRAUTLILIE_2);
    public static final RegistryObject<Item> BRAUTLILIE_GETOPFT = blockItem("brautlilie_getopft", ModBlocks.BRAUTLILIE_GETOPFT);
    public static final RegistryObject<Item> BRAUTLILIE_RIESIG = blockItem("brautlilie_riesig", ModBlocks.BRAUTLILIE_RIESIG);

    public static final RegistryObject<Item> SCHWERTLILIE = blockItem("schwertlilie", ModBlocks.SCHWERTLILIE);
    public static final RegistryObject<Item> SCHWERTLILIE_MEHRSTAEMMIG = blockItem("schwertlilie_mehrstaemmig", ModBlocks.SCHWERTLILIE_MEHRSTAEMMIG);
    public static final RegistryObject<Item> SEEROSENLILIE = blockItem("seerosenlilie", ModBlocks.SEEROSENLILIE);
    public static final RegistryObject<Item> SEEROSENLILIE_MEHRSTAEMMIG = blockItem("seerosenlilie_mehrstaemmig", ModBlocks.SEEROSENLILIE_MEHRSTAEMMIG);
    public static final RegistryObject<Item> TAGLILIE = blockItem("taglilie", ModBlocks.TAGLILIE);
    public static final RegistryObject<Item> TAGLILIE_MEHRSTAEMMIG = blockItem("taglilie_mehrstaemmig", ModBlocks.TAGLILIE_MEHRSTAEMMIG);
    public static final RegistryObject<Item> WUESTENLILIE = blockItem("wuestenlilie", ModBlocks.WUESTENLILIE);
    public static final RegistryObject<Item> WUESTENLILIE_MEHRSTAEMMIG = blockItem("wuestenlilie_mehrstaemmig", ModBlocks.WUESTENLILIE_MEHRSTAEMMIG);

    public static final RegistryObject<Item> KOENIGSLILIE_RIESIG = blockItem("koenigslilie_riesig", ModBlocks.KOENIGSLILIE_RIESIG);
    public static final RegistryObject<Item> TIGERLILIE_RIESIG = blockItem("tigerlilie_riesig", ModBlocks.TIGERLILIE_RIESIG);
    public static final RegistryObject<Item> TUERKENBUNDLILIE_RIESIG = blockItem("tuerkenbundlilie_riesig", ModBlocks.TUERKENBUNDLILIE_RIESIG);
    public static final RegistryObject<Item> ORIENTAL_ROT_RIESIG = blockItem("oriental_beetlilie_rot_riesig", ModBlocks.ORIENTAL_ROT_RIESIG);
    public static final RegistryObject<Item> ORIENTAL_PINK_RIESIG = blockItem("oriental_beetlilie_pink_riesig", ModBlocks.ORIENTAL_PINK_RIESIG);
    public static final RegistryObject<Item> ORIENTAL_WEISS_RIESIG = blockItem("oriental_beetlilie_weiss_riesig", ModBlocks.ORIENTAL_WEISS_RIESIG);
    public static final RegistryObject<Item> ORIENTAL_GELB_RIESIG = blockItem("oriental_beetlilie_gelb_riesig", ModBlocks.ORIENTAL_GELB_RIESIG);
    public static final RegistryObject<Item> MUTIERTE_TIGERLILIE_RIESIG = blockItem("mutierte_tigerlilie_riesig", ModBlocks.MUTIERTE_TIGERLILIE_RIESIG);
    public static final RegistryObject<Item> SCHWERTLILIE_RIESIG = blockItem("schwertlilie_riesig", ModBlocks.SCHWERTLILIE_RIESIG);
    public static final RegistryObject<Item> SEEROSENLILIE_RIESIG = blockItem("seerosenlilie_riesig", ModBlocks.SEEROSENLILIE_RIESIG);
    public static final RegistryObject<Item> TAGLILIE_RIESIG = blockItem("taglilie_riesig", ModBlocks.TAGLILIE_RIESIG);
    public static final RegistryObject<Item> WUESTENLILIE_RIESIG = blockItem("wuestenlilie_riesig", ModBlocks.WUESTENLILIE_RIESIG);
}
