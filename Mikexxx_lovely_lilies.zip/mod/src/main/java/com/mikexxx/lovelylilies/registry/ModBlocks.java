package com.mikexxx.lovelylilies.registry;

import com.mikexxx.lovelylilies.LovelyLilies;
import com.mikexxx.lovelylilies.block.GiantPlantBlock;
import com.mikexxx.lovelylilies.block.OrganicDoublePlantBlock;
import com.mikexxx.lovelylilies.block.OrganicPlantBlock;
import com.mikexxx.lovelylilies.block.PottedBrideLilyBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.SoundType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, LovelyLilies.MOD_ID);

    public static final List<RegistryObject<Block>> ALL_PLANTS = new ArrayList<>();

    private static final BlockBehaviour.Properties ONE = BlockBehaviour.Properties.of()
            .mapColor(MapColor.PLANT).noCollission().instabreak().sound(SoundType.GRASS);
    private static final BlockBehaviour.Properties TWO = BlockBehaviour.Properties.of()
            .mapColor(MapColor.PLANT).noCollission().instabreak().sound(SoundType.GRASS);
    private static final BlockBehaviour.Properties GIANT = BlockBehaviour.Properties.of()
            .mapColor(MapColor.PLANT).noOcclusion().instabreak().sound(SoundType.GRASS);
    private static final BlockBehaviour.Properties POT = BlockBehaviour.Properties.of()
            .mapColor(MapColor.TERRACOTTA_WHITE).strength(0.2f).sound(SoundType.STONE);

    private ModBlocks() {}

    private static RegistryObject<Block> one(String name) {
        RegistryObject<Block> b = BLOCKS.register(name, () -> new OrganicPlantBlock(ONE));
        ALL_PLANTS.add(b);
        return b;
    }

    private static RegistryObject<Block> two(String name) {
        RegistryObject<Block> b = BLOCKS.register(name, () -> new OrganicDoublePlantBlock(TWO));
        ALL_PLANTS.add(b);
        return b;
    }

    private static RegistryObject<Block> giant(String name) {
        RegistryObject<Block> b = BLOCKS.register(name, () -> new GiantPlantBlock(GIANT));
        ALL_PLANTS.add(b);
        return b;
    }

    private static RegistryObject<Block> pot(String name) {
        RegistryObject<Block> b = BLOCKS.register(name, () -> new PottedBrideLilyBlock(POT));
        ALL_PLANTS.add(b);
        return b;
    }

    // True lilies: two-block species.
    public static final RegistryObject<Block> KOENIGSLILIE = two("koenigslilie");
    public static final RegistryObject<Block> TIGERLILIE = two("tigerlilie");
    public static final RegistryObject<Block> TUERKENBUNDLILIE = two("tuerkenbundlilie");

    // Four one-block Oriental bed-lily variants.
    public static final RegistryObject<Block> ORIENTAL_ROT = one("oriental_beetlilie_rot");
    public static final RegistryObject<Block> ORIENTAL_PINK = one("oriental_beetlilie_pink");
    public static final RegistryObject<Block> ORIENTAL_WEISS = one("oriental_beetlilie_weiss");
    public static final RegistryObject<Block> ORIENTAL_GELB = one("oriental_beetlilie_gelb");

    // Mutated tropical Tiger Lily.
    public static final RegistryObject<Block> MUTIERTE_TIGERLILIE = one("mutierte_tigerlilie");

    // Bride lily: 1-block, 2-block, potted, and oversized.
    public static final RegistryObject<Block> BRAUTLILIE = one("brautlilie");
    public static final RegistryObject<Block> BRAUTLILIE_2 = two("brautlilie_2");
    public static final RegistryObject<Block> BRAUTLILIE_GETOPFT = pot("brautlilie_getopft");
    public static final RegistryObject<Block> BRAUTLILIE_RIESIG = giant("brautlilie_riesig");

    // Non-Lilium plants whose German common names contain "Lilie".
    public static final RegistryObject<Block> SCHWERTLILIE = one("schwertlilie");
    public static final RegistryObject<Block> SCHWERTLILIE_MEHRSTAEMMIG = one("schwertlilie_mehrstaemmig");
    public static final RegistryObject<Block> SEEROSENLILIE = one("seerosenlilie");
    public static final RegistryObject<Block> SEEROSENLILIE_MEHRSTAEMMIG = one("seerosenlilie_mehrstaemmig");
    public static final RegistryObject<Block> TAGLILIE = one("taglilie");
    public static final RegistryObject<Block> TAGLILIE_MEHRSTAEMMIG = one("taglilie_mehrstaemmig");
    public static final RegistryObject<Block> WUESTENLILIE = one("wuestenlilie");
    public static final RegistryObject<Block> WUESTENLILIE_MEHRSTAEMMIG = one("wuestenlilie_mehrstaemmig");

    // 3-5 block-tall visual giant forms; collision remains a single small block.
    public static final RegistryObject<Block> KOENIGSLILIE_RIESIG = giant("koenigslilie_riesig");
    public static final RegistryObject<Block> TIGERLILIE_RIESIG = giant("tigerlilie_riesig");
    public static final RegistryObject<Block> TUERKENBUNDLILIE_RIESIG = giant("tuerkenbundlilie_riesig");
    public static final RegistryObject<Block> ORIENTAL_ROT_RIESIG = giant("oriental_beetlilie_rot_riesig");
    public static final RegistryObject<Block> ORIENTAL_PINK_RIESIG = giant("oriental_beetlilie_pink_riesig");
    public static final RegistryObject<Block> ORIENTAL_WEISS_RIESIG = giant("oriental_beetlilie_weiss_riesig");
    public static final RegistryObject<Block> ORIENTAL_GELB_RIESIG = giant("oriental_beetlilie_gelb_riesig");
    public static final RegistryObject<Block> MUTIERTE_TIGERLILIE_RIESIG = giant("mutierte_tigerlilie_riesig");
    public static final RegistryObject<Block> SCHWERTLILIE_RIESIG = giant("schwertlilie_riesig");
    public static final RegistryObject<Block> SEEROSENLILIE_RIESIG = giant("seerosenlilie_riesig");
    public static final RegistryObject<Block> TAGLILIE_RIESIG = giant("taglilie_riesig");
    public static final RegistryObject<Block> WUESTENLILIE_RIESIG = giant("wuestenlilie_riesig");

    static {
        // DeferredRegister objects are populated by Forge before gameplay; item registration is handled separately.
    }
}
