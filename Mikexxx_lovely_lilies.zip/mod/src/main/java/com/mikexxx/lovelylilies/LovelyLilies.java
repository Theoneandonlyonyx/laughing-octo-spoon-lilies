package com.mikexxx.lovelylilies;

import com.mikexxx.lovelylilies.registry.ModBlocks;
import com.mikexxx.lovelylilies.registry.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LovelyLilies.MOD_ID)
public final class LovelyLilies {
    public static final String MOD_ID = "lovely_lilies";

    public LovelyLilies() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
