package com.mikexxx.lovelylilies.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A deliberately small physical footprint paired with an oversized visual model.
 * The model may extend several blocks upward and past the 16x16 footprint.
 */
public class GiantPlantBlock extends OrganicPlantBlock {
    private static final VoxelShape GIANT_COLLISION = Block.box(2, 0, 2, 14, 16, 14);

    public GiantPlantBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return GIANT_COLLISION;
    }
}
